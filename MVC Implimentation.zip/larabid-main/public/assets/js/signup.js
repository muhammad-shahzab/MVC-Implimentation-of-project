
// const signup = document.getElementByClass("signup");

// signup.addEventListener("click" , ()=>{
//     window.location.href = "http://localhost:3000/pages/login.php"
// })